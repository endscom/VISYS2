-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 17-08-2016 a las 10:39:14
-- Versión del servidor: 5.1.36
-- Versión de PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `visys`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `IdRol` int(10) NOT NULL COMMENT 'Id de Rol',
  `Descripcion` varchar(250) NOT NULL COMMENT 'Descripcion del Rol',
  PRIMARY KEY (`IdRol`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `roles`
--

INSERT INTO `roles` (`IdRol`, `Descripcion`) VALUES
(1, 'SuperAdministrador'),
(2, 'Administrador'),
(3, 'Vendedor'),
(4, 'SAC'),
(5, 'CxC'),
(6, 'Mercadeo'),
(7, 'Cliente'),
(8, 'Corp.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `IdUsuario` int(50) NOT NULL AUTO_INCREMENT COMMENT 'Id de usuario',
  `Usuario` varchar(100) NOT NULL COMMENT 'Usuario',
  `Nombre` varchar(150) DEFAULT NULL COMMENT 'Nombre del usuario',
  `Clave` varchar(100) NOT NULL COMMENT 'Contraseña de Usuario',
  `Rol` varchar(100) NOT NULL COMMENT 'Tipo de Usuario',
  `IdCL` varchar(10) NOT NULL COMMENT 'Id del Cliente',
  `Cliente` varchar(250) DEFAULT NULL COMMENT 'Nombre del Cliente',
  `Zona` varchar(250) DEFAULT NULL COMMENT 'Nombre de Vendedor o Ruta',
  `Estado` bit(1) DEFAULT NULL COMMENT '0 Activo, 1 Inactivo',
  `FechaCreacion` datetime NOT NULL COMMENT 'Fecha de Creación del Usuario',
  `FechaBaja` datetime DEFAULT NULL COMMENT 'Fecha de Baja del Usuario',
  PRIMARY KEY (`IdUsuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=201 ;

--
-- Volcar la base de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`IdUsuario`, `Usuario`, `Nombre`, `Clave`, `Rol`, `IdCL`, `Cliente`, `Zona`, `Estado`, `FechaCreacion`, `FechaBaja`) VALUES
(1, 'admin', 'admin', '123', 'Administrador', '', NULL, '', b'0', '2016-06-27 00:00:00', '2016-08-09 15:32:21'),
(200, 'cliente1', 'FARMACIA PICHARDO - RUC 2910912590002X', '123', 'Cliente', '00019', 'FARMACIA PICHARDO - RUC 2910912590002X', 'F06', b'0', '2016-08-15 08:17:45', '2016-08-15 09:30:35');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vendedor`
--

CREATE TABLE IF NOT EXISTS `vendedor` (
  `IdVendedor` int(10) NOT NULL,
  `Nombre` varchar(150) NOT NULL,
  `Zona` varchar(20) NOT NULL,
  `Estado` bit(1) NOT NULL,
  PRIMARY KEY (`IdVendedor`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `vendedor`
--

INSERT INTO `vendedor` (`IdVendedor`, `Nombre`, `Zona`, `Estado`) VALUES
(1, 'F01', 'F01', b'0'),
(2, 'F02', 'F02', b'0'),
(3, 'F03', 'F03', b'0'),
(4, 'F04', 'F04', b'0'),
(5, 'F05', 'F05', b'0'),
(6, 'F06', 'F06', b'0'),
(7, 'F07', 'F07', b'0'),
(8, 'F08', 'F08', b'0'),
(9, 'F09', 'F09', b'0'),
(10, 'F10', 'F010', b'0'),
(11, 'F11', 'F011', b'0'),
(12, 'F12', 'F012', b'0'),
(13, 'F13', 'F013', b'0'),
(14, 'F14', 'F014', b'0'),
(15, 'F15', 'F015', b'0'),
(16, 'F16', 'F016', b'0'),
(17, 'F17', 'F017', b'0'),
(18, 'F18', 'F018', b'0'),
(19, 'F19', 'F019', b'0'),
(20, 'F20', 'F020', b'0'),
(21, 'F21', 'F021', b'0');
