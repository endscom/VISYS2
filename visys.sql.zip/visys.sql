-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 29-07-2016 a las 08:41:59
-- Versión del servidor: 5.1.36
-- Versión de PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `visys`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `IdRol` int(10) NOT NULL COMMENT 'Id de Rol',
  `Descripcion` varchar(250) NOT NULL COMMENT 'Descripcion del Rol',
  PRIMARY KEY (`IdRol`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `roles`
--

INSERT INTO `roles` (`IdRol`, `Descripcion`) VALUES
(1, 'SuperAdministrador'),
(2, 'Administrador'),
(3, 'Vendedor'),
(4, 'SAC'),
(5, 'CxC'),
(6, 'Mercadeo'),
(7, 'Cliente'),
(8, 'Corp.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `IdUsuario` int(50) NOT NULL AUTO_INCREMENT COMMENT 'Id de usuario',
  `Nombre` varchar(100) NOT NULL COMMENT 'Nombre de Usuario',
  `Clave` varchar(100) NOT NULL COMMENT 'Contraseña de Usuario',
  `Rol` varchar(100) NOT NULL COMMENT 'Tipo de Usuario',
  `FechaCreacion` datetime NOT NULL COMMENT 'Fecha de Creación del Usuario',
  `Recordar` int(10) DEFAULT NULL COMMENT 'Si desea que recuerde su nombre de usuario',
  `Estado` bit(1) DEFAULT NULL COMMENT '0 Activo, 1 Inactivo',
  `FechaBaja` datetime DEFAULT NULL COMMENT 'Fecha de Baja de Cliente',
  `Vendedor` varchar(10) DEFAULT NULL COMMENT 'Nombre de Vendedor o Ruta',
  `RUC` varchar(20) DEFAULT NULL COMMENT 'Numero RUC',
  PRIMARY KEY (`IdUsuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=57 ;

--
-- Volcar la base de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`IdUsuario`, `Nombre`, `Clave`, `Rol`, `FechaCreacion`, `Recordar`, `Estado`, `FechaBaja`, `Vendedor`, `RUC`) VALUES
(1, 'admin', '123', 'Administrador', '2016-06-27 00:00:00', 0, b'0', '2016-07-28 16:33:32', '', ''),
(55, 'test33', '123', 'Administrador', '2016-07-28 00:00:00', NULL, b'0', '2016-07-28 16:35:08', NULL, NULL),
(56, 'test', '123', 'Administrador', '2016-07-28 00:00:00', NULL, b'1', '2016-07-28 16:57:09', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vendedor`
--

CREATE TABLE IF NOT EXISTS `vendedor` (
  `IdVendedor` int(10) NOT NULL,
  `Nombre` varchar(150) NOT NULL,
  `Zona` varchar(20) NOT NULL,
  `Estado` bit(1) NOT NULL,
  PRIMARY KEY (`IdVendedor`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `vendedor`
--

INSERT INTO `vendedor` (`IdVendedor`, `Nombre`, `Zona`, `Estado`) VALUES
(1, 'F01', 'F01', b'0'),
(2, 'F02', 'F02', b'0'),
(3, 'F03', 'F03', b'0'),
(4, 'F04', 'F04', b'0'),
(5, 'F05', 'F05', b'0'),
(6, 'F06', 'F06', b'0'),
(7, 'F07', 'F07', b'0'),
(8, 'F08', 'F08', b'0'),
(9, 'F09', 'F09', b'0'),
(10, 'F010', 'F010', b'0'),
(11, 'F011', 'F011', b'0'),
(12, 'F012', 'F012', b'0');
