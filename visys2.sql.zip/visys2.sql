-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 07-07-2016 a las 22:08:55
-- Versión del servidor: 5.1.36
-- Versión de PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `visys`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `IdUsuario` int(50) NOT NULL AUTO_INCREMENT COMMENT 'Id de usuario',
  `NombreUsuario` varchar(100) NOT NULL COMMENT 'Nombre de Usuario',
  `Password` varchar(100) NOT NULL COMMENT 'Contraseña de Usuario',
  `TipoUsuario` varchar(100) NOT NULL COMMENT 'Tipo de Usuario',
  `Privilegio` int(10) NOT NULL COMMENT 'Privilegios de Usuario',
  `FechaCreacion` date NOT NULL COMMENT 'Fecha de Creación del Usuario',
  PRIMARY KEY (`IdUsuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`IdUsuario`, `NombreUsuario`, `Password`, `TipoUsuario`, `Privilegio`, `FechaCreacion`) VALUES
(1, 'admin', '123', 'Administrador', 0, '2016-06-27');
